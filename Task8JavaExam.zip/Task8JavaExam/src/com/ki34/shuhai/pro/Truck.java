package com.ki34.shuhai.pro;

public class Truck extends Car {
    private int massOfTrailer;
    private int countOfWheel;

    public Truck(int massOfTrailer, int countOfWheel) {
        this.massOfTrailer = massOfTrailer;
        this.countOfWheel = countOfWheel;
    }
    public void showInformationAboutCar(){
        System.out.println("mass of trailer = "+massOfTrailer);
        System.out.println("count of wheel" + countOfWheel);
    }

}
