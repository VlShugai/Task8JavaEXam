package com.ki34.shuhai.pro;

import java.lang.annotation.*;
import java.util.Scanner;

@Target(value = ElementType.METHOD)
@Retention(value = RetentionPolicy.RUNTIME)
@interface Vehicle {
    boolean ride();
}

public class Car implements Vehicle {
    Scanner sc = new Scanner(System.in);

    public void startRide(boolean isRide) {
        if (isRide) {
            System.out.println("ride");
        } else {
            System.out.println("stop");
        }
    }

    @Override
    public boolean ride() {
        System.out.println("1-Start");
        System.out.println("2-Stop");
        int menuCounter = 0;
        menuCounter = sc.nextInt();
        if (menuCounter==1)
            return true;
        else if(menuCounter==2)
            return false;
        return false;
    }

    @Override
    public Class<? extends Annotation> annotationType() {
        return null;
    }
}
